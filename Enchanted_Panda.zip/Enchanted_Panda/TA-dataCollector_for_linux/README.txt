Technology Add-on: TA-vm_stats

This TA collects VM stats from Linux and Windows via scripted input every 5 minutes.
- Output format: flat JSON
- Compatible with Splunk UF
- Place in $SPLUNK_HOME/etc/apps/

Customize:
- Update interval or index in default/inputs.conf
